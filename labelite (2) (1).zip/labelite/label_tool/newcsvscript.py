import datetime
import pandas as pd
import pytz
import psycopg2

###### File 1 ######

ndf = pd.read_csv('new_list.csv')

ndf['img'] = 'pics/' + ndf['img']

ndf.set_index('img_ID', inplace=True)
ndff = ndf.loc[910]

ls = ndff.index
# ls = ls[1::]
type(ls)
list(ls)
i = 0
my_ls = []

newdff = pd.DataFrame(ndf, columns=['img', 'comment', 'reviewed', 'date_created', 'date_updated', 'author_id','unable_to_read_image'], dtype=str)
IST= pytz.timezone('Asia/Kolkata')

imgind = list(ndf.index)

for ind in imgind:
    # my_ls = []
    #i = 0
    # for el in ndf.loc[ind]:
    #     if el == 1:
    #         my_ls.append(ls[i])
    #     i = i+1
   # newdff.at[ind, 'labels'] = str(my_ls)
    newdff.at[ind, 'date_created'] = datetime.datetime.now(IST)
    newdff.at[ind, 'date_updated'] = datetime.datetime.now(IST)
    newdff.at[ind, 'author_id'] = 1
    newdff.at[ind, 'comment'] = None
    newdff.at[ind, 'reviewed'] = False
    newdff.at[ind, 'unable_to_read_image'] = False

    #if str(my_ls) == '[]':
    #   newdff.at[ind, 'reviewed'] = False
    #else:
    #   newdff.at[ind, 'reviewed'] = True
newdff.to_csv('new_file_withnolabel.csv', index=True)


###### File 2 ######
ndf = pd.read_csv('new_list.csv')
# ndf['img'] = 'pics/' + ndf['img'] + '.png'
ndf.set_index('img_ID', inplace=True)
ndff = ndf.loc[910]

ls = ndff.index
type(ls)
list(ls)
i = 0
my_ls = []
j = 902
lab_id = []
img_id = []


imgind = list(ndf.index)

for ind in imgind:
    #img_id.append(str(ind))
    i = 0
    for el in ndf.loc[ind]:
        if el == 1:
            my_ls.append(j)
            lab_id.append(i)
        i = i+1
    j = j+1
Tableb = pd.DataFrame(
    {'img_ID': my_ls,
     'label_ID': lab_id,
    })

Tableb.to_csv('Tableb.csv', index=False)

# ##File 3
# ndf = pd.read_csv('new_list.csv')
# dct = {
#     'label_id':list(range(1,17)),
#     'label_name': ndf.columns[2:]
# }
# label_table = pd.DataFrame(dct)
# label_table.to_csv('label_table.csv', index=False)

dbname='labelite'
user='postgres'
password='1234'
host='localhost'
port='5432'
con = psycopg2.connect(database=dbname,user=user,password=password,host=host,port=port)
cur = con.cursor()    

with open('new_file_withnolabel.csv') as f:
    cur.copy_expert('COPY public.home_imagedetail(img_id,img,comment,reviewed,date_created,date_updated,author_id,unable_to_read_image) FROM STDIN WITH HEADER CSV', f)
    
with open('Tableb.csv') as f1:
    cur.copy_expert('COPY public.home_imagedetail_labels(imagedetail_id,labelchoice_id) FROM STDIN WITH HEADER CSV', f1)

# with open('label_table.csv') as f2:
    # cur.copy_expert('COPY public.home_labelchoice(label_id,label_name) FROM STDIN WITH HEADER CSV', f2)

con.commit()
con.close()