from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic import (
    ListView,
    DetailView,
    CreateView,
    DeleteView
)
from .filters import filter
from .models import ImageDetail
from .forms import UpdateForm, CreateForm
# from .filters import ImageFilter



class ImageListView(LoginRequiredMixin, ListView):
    # myfilter = ImageFilter(request.GET, )
    model = ImageDetail
    template_name = 'home/imagedetail_list.html'
    context_object_name = 'objects'
    # filterset_class = ImageFilter
    # ordering = ['id']
    # queryset = ImageDetail.objects.all().order_by('img_id')
    paginate_by = 20

    def get_queryset(self):
        qs = filter(self.request)
        # print(qs)
        return qs

    
class SuperuserRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        return self.request.user.is_superuser
        
class ImageDetailView(LoginRequiredMixin, DetailView):
    model = ImageDetail
    # template_name = 'contactlist/user1.html'
    
class ImageCreateView(LoginRequiredMixin,SuperuserRequiredMixin, CreateView):
    form_class = CreateForm
    model = ImageDetail
    # fields = ['img']
    


@login_required
def ImageUpdate(request, pk):
    obj = ImageDetail.objects.get(img_id=pk)
    initial_dict = {
        "labels" : obj.labels,
        "comment": obj.comment,
        "unable_to_read_image":obj.unable_to_read_image
    }
    link = request.META.get('HTTP_REFERER')
    print(link)
    if request.method == 'POST':
        print(request.method)
        form = UpdateForm(request.POST or None, initial = initial_dict)
        if form.is_valid():
            print('valid form')
            labels = form.cleaned_data.get('labels')
            # labels = tuple(map(int, labels.split(',')))
            # lst = []
            # for label_id in labels:
                # label_inst = LabelChoice.objects.get(label_id=label_id)
                # lst.append(label_inst)
            # labels = LabelChoice.objects.filter(label_id__in=labels)
            comment = form.cleaned_data.get('comment')
            unable_to_read_image = form.cleaned_data.get('unable_to_read_image')
            
            if initial_dict["labels"] != labels or initial_dict["comment"] !=comment or initial_dict["unable_to_read_image"] != unable_to_read_image:
                 obj.reviewed = True
                 obj.author = request.user
                 for label in labels:
                     obj.labels.add(label)
    
                 obj.comment = comment
                 obj.unable_to_read_image=unable_to_read_image
                 obj.save()
                 print(link)
            return HttpResponseRedirect(request.session['back_link'])
    else:
        print('else')
        request.session['back_link'] = request.META.get('HTTP_REFERER')
        form = UpdateForm(instance=obj)
        return render(request,'home/updateform.html', {'form':form, 'obj':obj})


class ImageDeleteView(LoginRequiredMixin, SuperuserRequiredMixin, DeleteView):
    model = ImageDetail
    success_url = '/'