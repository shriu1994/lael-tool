from django.db import models
from django.urls import reverse
from django.contrib.auth.models import User
# Create your models here.


attribute_choice = [
    ('No Finding','No Finding'),   
    ('Atelectasis','Atelectasis'),('Cardiomegaly','Cardiomegaly'), ('Cardiomegaly','Consolidation'),
    ('Covid 19','Covid 19'), ('Edema','Edema'),('Emphysema','Emphysema'),
    ('Fibrosis','Fibrosis'), ('Infiltration','Infiltration'), ('Mass','Mass'), 
    ('Nodule','Nodule'), ('Pleural Effusion','Pleural Effusion'),
    ('Pleural Thickening','Pleural Thickening'), ('Pneumonia','Pneumonia'),
    ('Pneumothorax','Pneumothorax'), ('Soft tissue Emphysema','Soft tissue Emphysema'),
    
]

class LabelChoice(models.Model):
    label_id = models.IntegerField(primary_key=True)
    label_name = models.CharField(max_length=50, null=True)
    # label = models.ForeignKey(ImageDetail, on_delete=models.SET_NULL, blank=True, null=True )
    
    def __str__(self):
        return str(self.label_name)
    
class ImageDetail(models.Model):
    img_id = models.IntegerField(primary_key=True,unique=True)
    img= models.ImageField(upload_to='pics')
    # labels = models.CharField(max_length=1000, choices=attribute_choice,null=True, blank=True)
    comment = models.TextField(null=True, blank=True)
    reviewed = models.BooleanField(default=False)
    date_created = models.DateTimeField(auto_now_add=True)
    date_updated = models.DateTimeField(auto_now=True)
    labels = models.ManyToManyField(LabelChoice, blank=True, related_name='imagedetail')
    author = models.ForeignKey(User, on_delete=models.CASCADE, blank=True, null=True)
    unable_to_read_image = models.BooleanField(default=False)
    
    def __str__(self):
        return str(self.img_id)

    def get_absolute_url(self):
        return reverse('home')
    

    
# attribute_choice = [
#     ('0','No Finding'),   
#     ('1','Atelectasis'),('2','Cardiomegaly'), ('3','Consolidation'),
#     ('4','Covid 19'), ('5','Edema'),('6','Emphysema'),
#     ('7','Fibrosis'), ('8','Infiltration'), ('9','Mass'),
    
#     ('q','Nodule'), ('w','Pleural Effusion'),
#     ('e','Pleural Thickening'), ('t','Pneumonia'),
#     ('a','Pneumothorax'), ('s','Soft tissue Emphysema'),
    
# ]