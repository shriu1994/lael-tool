from django.urls import path
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf.urls.static import static
from django.conf import settings
from .views import (
  ImageListView,
  # ImageFilterListView,
  ImageCreateView,
  ImageDetailView,
  ImageUpdate,
  ImageDeleteView 
)

urlpatterns = [
    path('',ImageListView.as_view(),name = 'home'),
    # path('search/',ImageFilterListView.as_view(),name = 'filterhome'),
    path('details/<int:pk>/',ImageDetailView.as_view(), name='details'),
    path('create/',ImageCreateView.as_view(), name='create'),
    path('details/<int:pk>/update',ImageUpdate, name='update'),
    path('details/<int:pk>/delete/',ImageDeleteView.as_view(), name='delete')
]

urlpatterns += staticfiles_urlpatterns()
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
