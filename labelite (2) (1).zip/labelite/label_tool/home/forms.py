from django.forms import ModelForm
from .models import ImageDetail, attribute_choice
from django import forms
 
# choices = LabelChoice.objects.all()
# choice_list = []
# print(choices)
# for choice in choices:
#     choice_list.append((choice.label_id, choice.label_name))
    
class UpdateForm(forms.ModelForm):
    unable_to_read_image = forms.BooleanField(required=False)
    class Meta:
        model = ImageDetail
        fields = ['labels','comment','unable_to_read_image']
        widgets = {
            'comment': forms.Textarea(attrs={'cols': 65, 'rows': 3}),
            'labels': forms.CheckboxSelectMultiple()
        }

class CreateForm(forms.ModelForm):
    class Meta:
        model = ImageDetail
        fields = ['img','labels']
        widgets = {
            'labels': forms.CheckboxSelectMultiple()
        }