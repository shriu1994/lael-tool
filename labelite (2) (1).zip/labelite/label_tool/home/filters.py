from .models import ImageDetail

def is_valid_queryparam(param):
    return param != '' and param is not None

def filter(request):
    order_param = request.GET.get('order_param')
    if order_param == None:
        order_param = 'img_id'
        
    qs = ImageDetail.objects.all().order_by(order_param)
    id_exact = request.GET.get('id_exact')
    if id_exact == "":
        id_exact = request.GET.get('id_exact')
        
    elif isinstance(id_exact,str):
    # else:
        id_exact = tuple(map(int, id_exact.split('-')))
        if len(id_exact)!=1:
            id_exact = range(id_exact[0],id_exact[1]+1)
    # print(id_exact)
    id_min = request.GET.get('id_min')
    id_max = request.GET.get('id_max')
    date_min = request.GET.get('date_min')
    date_max = request.GET.get('date_max')
    reviewer = request.GET.get('reviewer')
    reviewed = request.GET.get('reviewed')
    not_reviewed = request.GET.get('notReviewed')
    notreadable = request.GET.get('notreadable')
    
    if is_valid_queryparam(id_exact):
            qs = qs.filter(img_id__in=id_exact)
    
    if is_valid_queryparam(id_min):
            qs = qs.filter(img_id__gte=id_min)
            
    if is_valid_queryparam(id_max):
            qs = qs.filter(img_id__lte=id_max)
    
    if is_valid_queryparam(date_min):
            qs = qs.filter(date_updated__gte=date_min)
    
    if is_valid_queryparam(date_max):
            qs = qs.filter(date_updated__gte=date_max)
            
    if is_valid_queryparam(reviewer):
            qs = qs.filter(author__username__icontains=reviewer)
            
    if reviewed == 'on' and not_reviewed == 'on':
        pass
    
    elif reviewed == 'on':
        qs = qs.filter(reviewed=True)

    elif not_reviewed == 'on':
        qs = qs.filter(reviewed=False)

    if notreadable == 'on':
        qs = qs.filter(unable_to_read_image=True)
            
    return qs