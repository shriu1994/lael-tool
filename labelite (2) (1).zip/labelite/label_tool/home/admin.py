from django.contrib import admin
from .models import ImageDetail,LabelChoice
from import_export import resources
from import_export.admin import ImportExportModelAdmin

class ImageDetailResource(resources.ModelResource):

    class Meta:
        model = ImageDetail
        fields = ('img_id','author__username','labels','comment','date_updated')
        export_order = ('img_id','author__username','labels','comment','date_updated')
  
class ImageDetailAdmin(ImportExportModelAdmin):
    list_filter = ('reviewed','unable_to_read_image')
    resource_class = ImageDetailResource
          
# Register your models here.
admin.site.register(ImageDetail, ImageDetailAdmin)
admin.site.register(LabelChoice)
