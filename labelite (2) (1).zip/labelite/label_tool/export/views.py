from django.shortcuts import render
from home.models import ImageDetail
from home.filters import filter
import csv
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import ListView

# Create your views here.

def export_home(request):
    # date_min = request.GET.get('date_min')   
    # print(date_min)
    # qs = filter(request)
    # request.session['request'] = request
    return render(request, 'export/export_home.html')
    

class ListExportView(LoginRequiredMixin, ListView):
    # myfilter = ImageFilter(request.GET, )
    model = ImageDetail
    template_name = 'export/export_download.html'
    context_object_name = 'objects'
    # filterset_class = ImageFilter
    # ordering = ['id']
    # queryset = ImageDetail.objects.all().order_by('img_id')
    # paginate_by = 20

    def get_queryset(self):
        qs = filter(self.request)
        # print(qs)
        return qs

    def render_to_response(self, context, **response_kwargs):
        objects = context.get('objects') 
        images = objects.values_list('img_id','comment', 'labels','reviewed','author__username')
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="reports.csv"'
        writer = csv.writer(response)
        writer.writerow(['img_id','comment','labels','reviewed', 'Last Updated By'])
        for img in images:
           writer.writerow(img)
        return response

    
# def export_download(request):
#     print(request.method)
#     filter_request = request.META.get('HTTP_REFERER')
#     print(filter_request)
#     # filter_request1= requests.get(filter_request)

#     # qs = filter(filter_request1)
#     response = HttpResponse(content_type='text/csv')


#     writer = csv.writer(response)
#     writer.writerow(['img_id', 'labels', 'comment', 'reviewed'])

#     for member in ImageDetail.objects.all().values_list('img_id', 'labels', 'comment', 'reviewed'):
#         writer.writerow(member)

#     response['Content-Disposition'] = 'attachment; filename="members.csv"'

#     return response