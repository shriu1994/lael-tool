from django.urls import path
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf.urls.static import static
from django.conf import settings
from .views import (
export_home,
# export_download,
ListExportView
)

urlpatterns = [
    path('',export_home, name='export_home'),
    path('download/',ListExportView.as_view(), name='export_download'),
]
